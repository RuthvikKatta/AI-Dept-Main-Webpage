let selectedFile;
let rowObject;

document.getElementById("input").addEventListener("change",(event)=>{
    selectedFile = event.target.files[0];
    if(selectedFile){
        let filereader = new FileReader();
        filereader.readAsBinaryString(selectedFile);
        filereader.onload = (event) => {
            let data = event.target.result;
            let workbook = XLSX.read(data,{type:'binary'});
            workbook.SheetNames.forEach(sheet =>{
                rowObject = XLSX.utils.sheet_to_json(workbook.Sheets[sheet]);
            });
        }
    }
})



document.getElementById("button").addEventListener('click',function(){
    const main = document.querySelector('.main');
    while (main.firstChild){
        main.removeChild(main.lastChild);
      }
    for(let one of rowObject){
        let NewElement = document.createElement("div");
        NewElement.classList.add("tab");
        const Total  = one.Mid1 + one.Mid2 + one.Mid3;

        var smallest;
        if(one.Mid1 < one.Mid2 && one.Mid1 < one.Mid3) smallest = one.Mid1;
        else if(one.Mid2 < one.Mid1 && one.Mid2 < one.Mid3) smallest = one.Mid2;
        else smallest = one.Mid3; 
        
        var val = Math.round((Total-smallest)/2);
        NewElement.innerHTML = `
        <p>${one.Name}</p>
        <p>${one.Mid1}</p>
        <p>${one.Mid2}</p>
        <p>${one.Mid3}</p>
        <p>${val}</p>
        `;
        document.querySelector('.main').appendChild(NewElement);
    }
})
